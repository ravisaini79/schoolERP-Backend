const role = {
  Student: "student",
  Teacher: "teacher",
  NonTeacher: "nonteacher",
  Admin: "admin",
  SuperAdmin: "Superadmin",
};

module.exports = {
  role,
};
